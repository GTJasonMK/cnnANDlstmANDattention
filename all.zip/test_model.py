from __future__ import annotations

import argparse
import os
from typing import Optional

import torch

from config import load_config
from evaluator import evaluate_model
from main import prepare_run, setup_env
from visualizer import (
    plot_predictions, plot_residual_hist, plot_multihorizon_error,
    plot_attention_heatmap, plot_attention_multihead, plot_param_count,
)


def test_only(config_path: Optional[str], checkpoint_path: str, save_dir: Optional[str] = None, visualize: bool = True, output_dir: Optional[str] = None):
    """
    仅评估：加载检查点，基于配置构建数据与模型，在测试集上输出指标并可视化。

    Args:
        config_path: 配置文件路径（JSON/YAML）。
        checkpoint_path: 训练好的模型检查点（如 checkpoints/model_best.pt）。
        save_dir: 可视化输出目录；若为 None 则使用配置/默认目录。
        visualize: 是否生成图像。

    Returns:
        metrics: 一个包含 MSE/MAE/RMSE/MAPE 的字典。
    """
    cfg = load_config(config_path)

    # 覆盖可视化参数
    if output_dir is not None:
        cfg.output_dir = output_dir
    if save_dir is not None:
        cfg.visual_save_dir = save_dir
    cfg.visual_enabled = bool(visualize)

    # 环境与数据/模型准备
    setup_env(cfg)
    data, model, (train_loader, val_loader, test_loader) = prepare_run(cfg)

    # 使用 Trainer 的设备管理与checkpoint加载
    from trainer import Trainer
    trainer = Trainer(model, cfg)
    last_epoch = trainer.load_checkpoint(checkpoint_path)
    print(f"Loaded checkpoint from epoch {last_epoch}")

    # 参数量
    try:
        param_count = sum(p.numel() for p in model.parameters())
        if visualize and getattr(cfg, 'visual_enabled', True):
            plot_param_count(param_count)
    except Exception:
        pass

    # 指标评估（测试集）
    metrics = evaluate_model(model, test_loader, trainer.device)
    print({k: round(v, 6) for k, v in metrics.items()})

    # 预测与可视化
    if visualize and getattr(cfg, 'visual_enabled', True):
        preds, targets = trainer.predict(test_loader)
        plot_predictions(preds, targets)
        plot_residual_hist(preds, targets)
        plot_multihorizon_error(preds, targets)

        # 注意力（若模型包含注意力模块）
        model.eval()
        with torch.no_grad():
            for x, _ in test_loader:
                x = x.to(trainer.device, non_blocking=True)
                out = model(x, return_attn=True)
                if isinstance(out, tuple) and len(out) == 2:
                    _, attn = out
                else:
                    attn = None
                plot_attention_heatmap(attn)
                if attn is not None:
                    plot_attention_multihead(attn)
                break

    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate a trained model on test set and visualize results.")
    parser.add_argument("--config", type=str, default=None, help="Path to JSON/YAML config file")
    parser.add_argument("--checkpoint", type=str, required=True, help="Path to model checkpoint (e.g., checkpoints/model_best.pt)")
    parser.add_argument("--output_dir", type=str, default=None, help="Base output directory (overrides config.output_dir)")
    parser.add_argument("--save_dir", type=str, default=None, help="Directory to save visualizations (overrides config.visual_save_dir)")
    parser.add_argument("--no_visualize", action="store_true", help="Disable visualization and only print metrics")
    args = parser.parse_args()

    visualize = not args.no_visualize
    metrics = test_only(args.config, args.checkpoint, save_dir=args.save_dir, visualize=visualize, output_dir=args.output_dir)
    # 控制台已打印指标，函数返回便于其他脚本调用

