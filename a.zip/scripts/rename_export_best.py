from __future__ import annotations

import argparse
import os
import json
import hashlib
from pathlib import Path
from typing import Dict, Any

import torch


def slug_from_cfg(cfg: Dict[str, Any]) -> str:
    m = (cfg.get('model') or {})
    cnn = str(((m.get('cnn') or {}).get('variant') or 'standard')).strip().lower()
    tcn_enabled = bool(((m.get('tcn') or {}).get('enabled') or False) or cnn == 'tcn')
    cnn_tag = 'tcn' if tcn_enabled else cnn
    lstm = (m.get('lstm') or {})
    rnn_type = str(lstm.get('rnn_type') or 'lstm').strip().lower()
    attn = (m.get('attention') or {})
    attn_variant = str(attn.get('variant') or 'standard').strip().lower()
    pos_mode = str(attn.get('positional_mode') or 'none').strip().lower()
    ca_on = bool(((m.get('cnn') or {}).get('use_channel_attention') or False))
    bi = bool(lstm.get('bidirectional') if 'bidirectional' in lstm else True)
    heads = int(attn.get('num_heads') or 0)
    return f"{cnn_tag}-{rnn_type}-{attn_variant}-pos{pos_mode}-ca{'on' if ca_on else 'off'}-{'bi' if bi else 'uni'}-H{heads}"


def main():
    ap = argparse.ArgumentParser(description='Rename 3-letter export best checkpoints to human-readable slug names')
    ap.add_argument('--dir', required=True, help='Directory containing exported best .pt files')
    ap.add_argument('--dry-run', action='store_true', help='Print actions without renaming')
    args = ap.parse_args()

    root = Path(args.dir)
    if not root.exists():
        print(f"Directory not found: {root}")
        return

    for pt in sorted(root.glob('*.pt')):
        try:
            ckpt = torch.load(str(pt), map_location='cpu')
            cfg = ckpt.get('cfg') or {}
            slug = slug_from_cfg(cfg)
            hash_src = json.dumps((cfg.get('model') or {}), sort_keys=True, ensure_ascii=False)
            sh = hashlib.sha1(hash_src.encode('utf-8')).hexdigest()[:8]
            new_name = f"{slug}_{sh}.pt"
            dst = pt.with_name(new_name)
            if dst.name == pt.name:
                continue
            if dst.exists():
                print(f"[skip] target exists: {dst.name}")
                continue
            if args.dry_run:
                print(f"[dry] {pt.name} -> {dst.name}")
            else:
                pt.rename(dst)
                print(f"[ok]  {pt.name} -> {dst.name}")
        except Exception as e:
            print(f"[err] {pt.name}: {e}")


if __name__ == '__main__':
    main()

